from google.colab import files
files.download("./G_latest.pth")
files.download("./finetune_speaker.json")
files.download("./moegoe_config.json")